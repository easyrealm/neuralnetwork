
import java.util.*;
import java.io.*;

public class Net
{
    private double alpha;
    private double beta;
    private double threshold;
    private int iteration;
    private double[][] input = null;
    private double[][] target = null;
    private int[] layerConfig;
    private int layerCount;
    private double[][] delta;
    private double[][] output;
    private double[][][] weights;
    private double[][][] prevDwts;
    private List<Double> errorData = new ArrayList<Double>();
    private final int RAND_MAX = 32768;
    private Random rand = new Random();


    public Net(double alpha, double beta, double threshold, int iteration, double[][] input, double[][] target, int[] layerConfig)
    {
        this.alpha = alpha;
        this.beta = beta;
        this.threshold = threshold;
        this.iteration = iteration;
        this.input = input;
        this.target = target;
        this.layerConfig = layerConfig;
        init();
    }

    public Net(double alpha, double beta, double threshold, int iteration, int[] layerConfig) {
        this.alpha = alpha;
        this.beta = beta;
        this.threshold = threshold;
        this.iteration = iteration;
        this.layerConfig = layerConfig;
        init();
    }
    
    private void init()
    {
        layerCount = layerConfig.length;

        //initializing the weights
        weights = new double[layerCount][][];
        for(int i=1;i<layerCount;i++)
        {
            weights[i] = new double[layerConfig[i]][];
            for(int j=0;j<layerConfig[i];j++)
            {
                weights[i][j] = new double[layerConfig[i-1] + 1];
                for(int k=0; k<layerConfig[i-1] + 1;k++)
                    //weights[i][j][k] = (new Random()).nextDouble();
                    weights[i][j][k] = (double)rand.nextInt(RAND_MAX)/(double)(RAND_MAX/2.0) - 1.0;
            }
        }
        
        //initializing the change in weights
        prevDwts = new double[layerCount][][];
        for(int i=1;i<layerCount;i++)
        {
            prevDwts[i] = new double[layerConfig[i]][];
            for(int j=0;j<layerConfig[i];j++)
            {
                prevDwts[i][j] = new double[layerConfig[i-1] + 1];
                for(int k=0; k<layerConfig[i-1] + 1;k++)
                    prevDwts[i][j][k] = (double)0.0;
            }
        }

        //initialize output of each neurone on each layer
        output = new double[layerCount][];
        delta = new double[layerCount][];
        for(int i=0;i<layerCount;i++)
        {
            output[i] = new double[layerConfig[i]];
            delta[i] = new double[layerConfig[i]];
            for(int j=0;j<layerConfig[i];j++)
            {
                output[i][j] = 0.0;
                delta[i][j] = 0.0;
            }
        }
    }

    private double[][] loadData(File file) throws IOException
    {
        StringBuilder fileData = new StringBuilder(1000);
        BufferedReader br = new BufferedReader(new FileReader(file));
        char[] buf = new char[1024];
        int numRead = 0;
        while((numRead = br.read(buf))!=-1)
        {
            String readData = String.valueOf(buf,0,numRead);
            fileData.append(readData);
            buf = new char[1024];
        }
        br.close();

        int i = 0 ;
        int j = 0;
        String[] lines = fileData.toString().split("\n");
        double[][] arr = new double[lines.length][];
        for(String line:lines)
        {
            if(line.length() == 0)continue;
            j = 0;
            String[] data = line.split(",");
            arr[i] = new double[data.length];
            for(String s:data)
            {
                arr[i][j] = (new Double(s)).doubleValue();
                j++;
            }
            i++;
        }
        return arr;
    }
    public void loadInput(File file) throws IOException
    {
        input = loadData(file);
        //print(input);
    }
    public void loadTarget(File file) throws IOException
    {
        target = loadData(file);
        //print(target);
    }
    public void saveWeights(File file) throws IOException
    {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        oos.writeObject(weights);
        oos.close();
    }

    public void loadWieghts(File file) throws IOException, ClassNotFoundException
    {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
        weights = (double[][][])ois.readObject();
        ois.close();
    }

    public void saveConfig(File file) throws IOException
    {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        oos.writeObject(layerConfig);
        oos.close();
    }

    public void loadConfig(File file) throws IOException, ClassNotFoundException
    {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
        layerConfig = (int[])ois.readObject();
        layerCount = layerConfig.length;
        ois.close();
    }

    private void print(double[][] arr)
    {
        if(arr == null)
        {
            System.out.println("Empty");
            return;
        }
        for(double[] inarr:arr)
        {
            String s = "";
            for(double in:inarr)s = s + in + ",";
            System.out.println(s);
        }
    }

    public void loadData(File file, int sep) throws IOException
    {
        StringBuilder fileData = new StringBuilder(1000);
        BufferedReader br = new BufferedReader(new FileReader(file));
        char[] buf = new char[1024];
        int numRead = 0;
        while((numRead = br.read(buf))!=-1)
        {
            String readData = String.valueOf(buf,0,numRead);
            fileData.append(readData);
            buf = new char[1024];
        }
        br.close();

        int i = 0 ;
        int j = 0;
        String[] lines = fileData.toString().split("\n");
        input = new double[lines.length][];
        target = new double[lines.length][];
        for(String line:lines)
        {
            if(line.length() == 0)continue;
            j = 0;
            String[] data = line.split(",");
            input[i] = new double[sep];
            target[i] = new double[data.length - sep];
            for(String s:data)
            {
                if(j > sep - 1)
                {
                    target[i][j - sep] = (new Double(s)).doubleValue();
                }
                else
                {
                    input[i][j] = (new Double(s)).doubleValue();
                }
                j++;
            }
            i++;
        }
        //print(input);
        //print(target);
    }

    private void printdelta()
    {

        for(int i=0;i<layerCount;i++)
        {
            String s = "[";
            for(int j=0;j<layerConfig[i];j++)
            {
                if(j != layerConfig[i] - 1)s = s  + delta[i][j] + ",";
                else s = s  + delta[i][j] +"]";
            }
            System.out.println(s);
        }
    }

    private void printweights()
    {
        for(int i=1;i<layerCount;i++)
        {
            String s = "[";
            for(int j=0;j<layerConfig[i];j++)
            {
                s = s + "(";
                for(int k=0; k<layerConfig[i-1] + 1;k++)
                    if(k != layerConfig[i-1])s = s + weights[i][j][k] + ",";
                    else s = s + weights[i][j][k];
                if(j != layerConfig[i] - 1)s = s + "),";
                else s = s + ")";
            }
            System.out.println(s + "]");
        }
    }

    private double dapprox(double value)
    {
        String s = String.format("%.2f", value);
        return Double.parseDouble(s);
    }

    private double sigmoid(double value)
    {
        return 1.0/(1.0 + Math.exp(-value));
    }

    private double mse(double[] target)
    {
        double mse = 0.0;
        for(int i=0;i<target.length;i++)
            mse += Math.pow(target[i] - output[layerCount - 1][i],2);
        return mse/2.0;
    }

    private void ffwd(double[] in)
    {
        for(int i=0;i<layerConfig[0];i++)
            output[0][i] = in[i];
        for(int i=1;i<layerCount;i++)
        {
            for(int j=0;j<layerConfig[i];j++)
            {
                double sum = 0.0;
                for(int k=0;k<layerConfig[i - 1];k++)
                    sum += output[i - 1][k] * weights[i][j][k];
                //apply bias
                sum += weights[i][j][layerConfig[i - 1]];
                output[i][j] = sigmoid(sum);
            }
        }
        
    }

    private void bkwd(double[] tgt)
    {
        //compute delta for output layer
        for(int i=0;i<layerConfig[layerCount - 1];i++)
        {
            delta[layerCount - 1][i] = output[layerCount - 1][i] * (1 - output[layerCount - 1][i]) * (tgt[i] - output[layerCount - 1][i]);
        }
        //compute delta for hidden layers
        for(int i=layerCount - 2;i>0;i--)
        {
            for(int j=0;j<layerConfig[i];j++)
            {
                double sum = 0.0;
                for(int k=0;k<layerConfig[i + 1]; k++)
                {
                    sum += delta[i + 1][k] * weights[i + 1][k][j];
                }
                delta[i][j] = output[i][j] * (1 - output[i][j]) * sum;
            }
        }
        //compute momentum based on alpha
        for(int i=1;i<layerCount;i++)
        {
            for(int j=0;j<layerConfig[i];j++)
            {
                for(int k=0;k<layerConfig[i-1];k++)
                {
                    weights[i][j][k] += alpha * prevDwts[i][j][k];
                }
                weights[i][j][layerConfig[i-1]] += alpha * prevDwts[i][j][layerConfig[i-1]];
            }
        }
        //adjust the weights
        for(int i=1;i<layerCount;i++)
        {
            for(int j=0;j<layerConfig[i];j++)
            {
                for(int k=0;k<layerConfig[i-1];k++)
                {
                    prevDwts[i][j][k] = beta * delta[i][j] * output[i - 1][k];
                    weights[i][j][k] += prevDwts[i][j][k];
                }
                //applying the bias
                prevDwts[i][j][layerConfig[i-1]] = beta * delta[i][j];
                weights[i][j][layerConfig[i-1]] += prevDwts[i][j][layerConfig[i-1]];
            }
        }
    }
    
    private void bpgt(double[] in, double[] out)
    {
        ffwd(in);
        bkwd(out);
    }

    private void train()
    {
        //printweights();
        //printdelta();
        int dataSize = input.length;
        for(int i=0;i<iteration;i++)
        {
            bpgt(input[i % dataSize], target[i % dataSize]);
            double error = mse(target[i % dataSize]);
            errorData.add(error);
            if(error < threshold)
            {
                System.out.println("Stopped at: " + i);
                break;
            }
        }
        //printdelta();
        //printweights();
        //for(double val:errorData)System.out.println(val);
    }

    private double[] test(double[] testdata)
    {
        ffwd(testdata);
        return output[layerCount - 1];
    }

    //test with input data
    public void test()
    {
        for(double[] in:input)
        {
            ffwd(in);
            String s = "";
            double[] out = output[layerCount - 1];
            for(double o:out)s=s+o+" ";
            System.out.println(s);
        }
    }

    public static void main(String[] args)
    {
        /*
        double beta = 0.3d;
        double alpha = 0.2d;
        double threshold = 0.00001d;        
        int iterCount = 100000;
        int layerCount = 4;
        int[] layerConfig = {3,3,3,1};
        double[][] input = {{0.0,0.0,0.0},{0.0,0.0,1.0},{0.0,1.0,0.0},{0.0,1.0,1.0},{1.0,0.0,0.0},{1.0,0.0,1.0},{1.0,1.0,0.0},{1.0,1.0,1.0}};
        double[][] target = {{0.0},{1.0},{1.0},{0.0},{1.0},{0.0},{0.0},{1.0}};
        Net net = new Net(alpha, beta, threshold, iterCount, input, target, layerConfig);
        net.train();
        for(double[] in:input)
        {
            String s = "";
            double[] out = net.test(in);
            for(double o:out)s = s + o + " ";
            System.out.println(s);
        }*/
	
        double beta = 0.3;
        double alpha = 0.01;
        double threshold = 0.000000000000001;
        int iterCount = 2000000;
        int layerCount = 3;
        int[] layerConfig = {17,30,1};//{17,30,17,1}
        Net net = new Net(alpha, beta, threshold, iterCount,layerConfig);
        try{
    	    //net.loadInput(new File("data\\input_fx_norm.csv"));
            //net.loadTarget(new File("data\\target_fx_norm.csv"));
            net.loadData(new File("data\\tlcraw_cluster01.csv"), 17);
            net.train();
            net.test();
            //save
            net.saveWeights(new File("data\\weights.wgt"));
            net.saveConfig(new File("data\\config.cfg"));

        }catch(IOException e)
        {
		System.out.println("File not found!");
	}
    }

}
