import java.util.Random;


public class SpectrumTracker
{
	private int n;
	private double[] p = null;
	private int[] tracker = null;
	private Random[] nodeRandGens = null;
	private Random specRandGen = null;
	private Random intRandGen = null;
	private Random trkRandGen = null;
	private int duration;
	private boolean start;
	private int nchecks;
	private final int MPERIOD = 10;
	private final int SPERIOD = 10;
	public SpectrumTracker(int n, int duration, double[] p)
	{
		this.n = n;
		this.nchecks = 0;
		this.duration = duration;
		this.tracker = new int[n];
		this.p = new double[n];
		this.start = false;
		specRandGen = new Random();
		nodeRandGens = new Random[n];
		intRandGen = new Random();
		trkRandGen = new Random();
		for(int i=0;i<n;i++)nodeRandGens[i] = new Random();
		for(int i=0;i<p.length;i++)this.p[i] = p[i];
		
	}
	public void run()
	{
		int counter = 0;
		int[] buffer = new int[n];
		int PERIOD = 0;
		int EXPPERIOD = 0;
		while(counter < duration)
		{
			int fbit = specRandGen.nextInt(2);
			for(int i=0;i<n;i++)
			{
				buffer[i] = (nodeRandGens[i].nextDouble() <= p[i])?Math.abs(1 - fbit):fbit;
			}
			if(!start)
			{
				//randomlly decide when to activate tracking
				if(Math.abs(trkRandGen.nextGaussian() / 3) < 0.02){
					PERIOD = MPERIOD + (int)(intRandGen.nextGaussian() * SPERIOD / 3);
					start = true;
					EXPPERIOD = PERIOD;
					System.out.println("Period = " + PERIOD);
				}
			}
			if(start)
			{
				for(int i=0;i<n;i++)
				{
					tracker[i] += (buffer[i]!= fbit)?1:0;
				}
				PERIOD--;
				if(PERIOD <= 0){
					start = false;
					nchecks++;
					for(int i=0;i<n;i++)
					{
						int tag = (((double)tracker[i] / (double)EXPPERIOD) > 0.45 )?-1:1;
						System.out.println(i + "," + tag);
						tracker[i] = 0;
					}
				}
			}
			counter++;
		}
		System.out.println("Number of Checks: " + nchecks);
	}
	public void run(int niter)
	{
		duration = niter;
		run();
	}
	public static void main(String[] args)
	{
		int n = 10;
		int niter = 100;
		double[] p = {0.4, 0.5, 0.6, 0.7, 0.45, 0.12, 0.15, 0.55, 0.01, 0.05};
		SpectrumTracker rst = new SpectrumTracker(n, niter, p);
		rst.run();		
	}
}
