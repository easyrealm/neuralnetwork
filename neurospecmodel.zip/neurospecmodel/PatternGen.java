

public class PatternGen
{
	private int n;
	private double[] p;
	private StringBuilder[] patterns = null;
	private Random[] rands = null;
	private Random specRand = new Random();
	public PatternGen(int n, double[] p)
	{
		this.n = n;
		this.p = new double[n];
		this.rands = new Random[n];
		this.patterns = new StringBuilder[n];
		for(int i=0;i<n;i++)
		{
			this.p[i] = p[i];
			this.rands = new Random();
			this.patterns = new StringBuilder();
		}
	}
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			int sbit = specRand.nextInt(2);
			for(int j=0;j<n;j++)
			{
				
			}
		}
	}
	public static void main(String[] args)
	{
		
	}
}
